awk '/bx/ {print $2}' pockcentroid3

#!/bin/bash
vmd receptor_out.pdb -e receptor.tcl

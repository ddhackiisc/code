#!/bin/bash
pymol receptor.pml

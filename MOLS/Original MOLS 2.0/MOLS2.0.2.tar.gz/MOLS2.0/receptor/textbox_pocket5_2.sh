awk '/bx/ {print $4}' pockcentroid5

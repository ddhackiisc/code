awk '/bx/ {print $4}' pockcentroid1

awk '/bx/ {print $6}' pockcentroid3

awk '/bx/ {print $2}' pockcentroid4

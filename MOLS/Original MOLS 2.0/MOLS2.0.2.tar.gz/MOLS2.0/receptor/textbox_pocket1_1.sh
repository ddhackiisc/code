awk '/bx/ {print $2}' pockcentroid1

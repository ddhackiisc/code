
obenergy -ff GAFF gcal_energy.mol2 > gene

#grep 'BOND STRETCHING ENERGY' ene > babelene.txt
#grep 'ANGLE BENDING ENERGY' ene >> babelene.txt
#grep 'TORSIONAL ENERGY' ene >> babelene.txt
#grep 'IMPROPER-TORSIONAL ENERGY' ene >> babelene.txt
#grep 'VAN DER WAALS ENERGY' ene >> babelene.txt
#grep 'ELECTROSTATIC ENERGY' ene >> babelene.txt
#grep 'TOTAL ENERGY' ene >> babelene.txt

awk '/TOTAL ENERGY/ {print $4}' gene > output1



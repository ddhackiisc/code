ifort -c sampar.f
ifort -o sampar sampar.o

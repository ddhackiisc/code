#include <unordered_map>
int main() {
  std::unordered_map<int, int> map;
  map[0] = 0;
  return 0;
}

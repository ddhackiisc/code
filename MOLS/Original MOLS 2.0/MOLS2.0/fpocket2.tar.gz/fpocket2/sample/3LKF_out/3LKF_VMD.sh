#!/bin/bash
vmd 3LKF_out.pdb -e 3LKF.tcl

#!/bin/bash
pymol 3LKF.pml
